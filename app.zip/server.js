'use strict';
/* Agent Core v2 — Growth Ventures Feature Funnel ka complete agent service.
   Channels: Web console (staff commands + tasks), WhatsApp webhook (staff → agent brain,
   leads → sales agent), Scheduler (daily report + follow-up reminders).
   Run: npm install && npm start  (PORT env, default 3000) */
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const store = require('./lib/store');
const kn = require('./lib/knowledge');
const svc = require('./lib/services');
const content = require('./lib/content');
const salesAgent = require('./lib/salesAgent');
const brain = require('./lib/agent');
const wa = require('./lib/whatsapp');
const scheduler = require('./lib/scheduler');
const { digits } = require('./lib/textutil');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'change-me';

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

const db = () => store.load();
const knowledge = () => kn.loadKnowledge();

/* ---------------- sessions ---------------- */
const sessions = new Map();
function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function auth(req, res, next) {
  const sid = parseCookies(req).ac_sid;
  if (sid && sessions.has(sid)) { req.user = sessions.get(sid); return next(); }
  if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'Not logged in' });
  return res.redirect('/login.html');
}
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    const sid = crypto.randomBytes(24).toString('hex');
    sessions.set(sid, { username, at: Date.now() });
    res.setHeader('Set-Cookie', `ac_sid=${sid}; HttpOnly; Path=/; SameSite=Lax; Max-Age=86400`);
    return res.json({ ok: true, username });
  }
  return res.status(401).json({ error: 'Galat username ya password' });
});
app.post('/api/logout', (req, res) => {
  const sid = parseCookies(req).ac_sid;
  if (sid) sessions.delete(sid);
  res.setHeader('Set-Cookie', 'ac_sid=; HttpOnly; Path=/; Max-Age=0');
  res.json({ ok: true });
});

/* ---------------- agent brain APIs ---------------- */
app.get('/api/agent/mode', auth, (req, res) => {
  res.json({ mode: brain.brainMode(), model: process.env.GEMINI_MODEL || 'gemini-2.5-flash', note: brain.brainMode() === 'gemini' ? 'Gemini function-calling active' : 'GEMINI_API_KEY set nahi — deterministic fallback planner active (saare tools chalte hain)' });
});
app.post('/api/agent/chat', auth, async (req, res) => {
  try {
    const out = await brain.runCommand({
      staffId: 'web:' + req.user.username,
      channel: 'web',
      text: (req.body && req.body.message) || ''
    });
    res.json({ taskId: out.task.id, reply: out.reply, steps: out.steps, status: out.status, brain: out.brain });
  } catch (e) {
    console.error('agent chat error', e);
    res.status(500).json({ error: 'Agent me masla aya, dobara try karein' });
  }
});
app.post('/api/agent/reset', auth, (req, res) => {
  const d = db();
  delete d.staffMemory['web:' + req.user.username];
  store.save();
  res.json({ ok: true });
});

/* ---------------- task log ---------------- */
app.get('/api/tasks', auth, (req, res) => {
  const list = [...db().tasks].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  res.json(list.slice(0, Number(req.query.limit) || 100));
});
app.get('/api/tasks/:id', auth, (req, res) => {
  const t = db().tasks.find(x => x.id === req.params.id);
  if (!t) return res.status(404).json({ error: 'Task nahi mila' });
  res.json(t);
});

/* ---------------- funnel read APIs (console ke liye) ---------------- */
app.get('/api/me', auth, (req, res) => res.json({ username: req.user.username }));
app.get('/api/dashboard', auth, (req, res) => res.json(svc.dashboardData(db())));
app.get('/api/leads', auth, (req, res) => res.json(db().leads));
app.get('/api/platforms', auth, (req, res) => res.json(db().platforms));
app.get('/api/followups', auth, (req, res) => res.json(svc.listFollowups(db(), req.query.status || undefined)));
app.get('/api/outbox', auth, (req, res) => res.json(wa.readOutbox().slice(-50)));

/* ---------------- knowledge / settings ---------------- */
app.get('/api/knowledge', auth, (req, res) => res.json(knowledge()));
app.put('/api/knowledge', auth, (req, res) => {
  const k = knowledge();
  const b = req.body || {};
  if (typeof b.businessName === 'string' && b.businessName.trim()) k.businessName = b.businessName.trim();
  if (typeof b.agentName === 'string' && b.agentName.trim()) k.agentName = b.agentName.trim();
  if (typeof b.salesAgentName === 'string' && b.salesAgentName.trim()) k.salesAgentName = b.salesAgentName.trim();
  if (typeof b.paymentInstructions === 'string') k.paymentInstructions = b.paymentInstructions;
  if (b.package && typeof b.package === 'object') {
    if (typeof b.package.name === 'string' && b.package.name.trim()) k.package.name = b.package.name.trim();
    if (b.package.price !== undefined && !isNaN(Number(b.package.price))) k.package.price = Number(b.package.price);
    if (Array.isArray(b.package.inclusions)) k.package.inclusions = b.package.inclusions.map(String);
    if (typeof b.package.deliveryDays === 'string') k.package.deliveryDays = b.package.deliveryDays;
  }
  if (Array.isArray(b.behaviourRules)) k.behaviourRules = b.behaviourRules.map(String);
  kn.saveKnowledge();
  res.json(k);
});

/* ---------------- lead sales agent (shared: test console + WhatsApp) ---------------- */
async function handleSalesMessage(sessionId, text, phoneHint) {
  const d = db();
  if (!d.agentSessions[sessionId]) d.agentSessions[sessionId] = { step: 'start', data: {}, history: [], leadId: null };
  const session = d.agentSessions[sessionId];
  if (phoneHint && !session.data.phone) session.data.phone = phoneHint;
  const settings = kn.compatSettings(d);
  const ctx = {
    db: d, settings, session, text,
    upsertLeadFromSession(sess) {
      let lead = sess.leadId ? svc.getLead(d, sess.leadId) : null;
      if (!lead) {
        lead = svc.createLead(d, {
          name: sess.data.name || sess.data.business,
          business: sess.data.business, city: sess.data.city, category: sess.data.category,
          phone: sess.data.phone || '', source: 'whatsapp', stage: 'payment_awaited',
          notes: 'WhatsApp Sales Agent se bani lead'
        });
        sess.leadId = lead.id;
      } else {
        lead.stage = 'payment_awaited'; svc.touch(lead);
      }
      lead.conversation = sess.history;
      store.save();
      return lead;
    }
  };
  const out = await salesAgent.handleMessage(ctx);
  if (session.leadId) {
    const lead = svc.getLead(d, session.leadId);
    if (lead) { lead.conversation = session.history; store.save(); }
  } else {
    store.save();
  }
  return { replies: out.replies, step: session.step, leadId: session.leadId || null };
}
app.post('/api/sales/chat', auth, async (req, res) => {
  try {
    const out = await handleSalesMessage((req.body && req.body.sessionId) || 'console-sales', (req.body && req.body.message) || '');
    res.json(out);
  } catch (e) {
    console.error('sales agent error', e);
    res.status(500).json({ error: 'Sales agent me masla aya' });
  }
});
app.post('/api/sales/reset', auth, (req, res) => {
  const d = db();
  delete d.agentSessions[(req.body && req.body.sessionId) || 'console-sales'];
  store.save();
  res.json({ ok: true });
});

/* design download (content verify ke liye) */
app.get('/api/leads/:id/design/:platformId', auth, (req, res) => {
  const l = svc.getLead(db(), req.params.id);
  if (!l || !l.content || !l.content.designs[req.params.platformId]) return res.status(404).send('Design nahi mila');
  res.setHeader('Content-Type', 'image/svg+xml');
  res.setHeader('Content-Disposition', `attachment; filename="design-${(l.business || 'lead').replace(/\s+/g, '-')}-${req.params.platformId}.svg"`);
  res.send(l.content.designs[req.params.platformId]);
});

/* invoice (printable) */
app.get('/api/leads/:id/invoice', auth, (req, res) => {
  const l = svc.getLead(db(), req.params.id);
  if (!l || !l.payment || !l.payment.confirmed) return res.status(404).send('Invoice sirf paid lead ke liye hai');
  const k = knowledge();
  const dt = new Date(l.payment.at).toLocaleDateString('en-PK');
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(`<!doctype html><html><head><meta charset="utf-8"><title>Invoice ${l.invoiceNo}</title>
<style>body{font-family:Arial,sans-serif;max-width:720px;margin:40px auto;color:#222}h1{color:#0b3d2e}table{width:100%;border-collapse:collapse;margin-top:20px}td,th{border:1px solid #ccc;padding:10px;text-align:left}.r{text-align:right}.tot{font-weight:bold;background:#f4f8f6}@media print{button{display:none}}</style></head>
<body><button onclick="window.print()">Print / Save PDF</button>
<h1>${content.esc(k.businessName)}</h1><p>Agent Core — Invoice</p>
<p><b>Invoice No:</b> ${l.invoiceNo}<br><b>Date:</b> ${dt}<br><b>Billed to:</b> ${content.esc(l.name)} (${content.esc(l.business)}, ${content.esc(l.city)})<br><b>WhatsApp:</b> ${content.esc(l.phone)}</p>
<table><tr><th>Description</th><th class="r">Amount (PKR)</th></tr>
<tr><td>${content.esc(k.package.name)} — feature on all 4 platforms<br><small>${content.esc(k.package.inclusions.join(', '))}</small></td><td class="r">${Number(l.payment.amount).toLocaleString('en-PK')}</td></tr>
<tr class="tot"><td>Total Paid (${content.esc(l.payment.method)}${l.payment.reference ? ' — Ref: ' + content.esc(l.payment.reference) : ''})</td><td class="r">Rs ${Number(l.payment.amount).toLocaleString('en-PK')}</td></tr></table>
<p style="margin-top:30px">Shukriya! — Team ${content.esc(k.businessName)}</p></body></html>`);
});

/* ---------------- WhatsApp Cloud API webhook ----------------
   GET  — Meta verification (WHATSAPP_VERIFY_TOKEN)
   POST — STAFF_NUMBERS → agent brain · baqi → lead sales agent
   Audio/voice note: transcription out of scope hai — text likhne ki request wapas jati hai. */
app.get('/webhooks/whatsapp', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  if (mode === 'subscribe' && token && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return res.status(200).send(challenge);
  }
  return res.status(403).send('Verification failed');
});
app.post('/webhooks/whatsapp', async (req, res) => {
  res.sendStatus(200);
  try {
    const entries = (req.body && req.body.entry) || [];
    for (const entry of entries) {
      for (const change of (entry.changes || [])) {
        const value = change.value || {};
        for (const msg of (value.messages || [])) {
          const from = msg.from;
          if (!from) continue;
          const staff = wa.isStaffNumber(from);
          if (msg.type !== 'text' || !msg.text || !msg.text.body) {
            // Voice note / media — graceful handling
            const note = msg.type === 'audio'
              ? (staff
                  ? 'Voice note mil gayi hai, lekin main voice abhi sun (transcribe) nahi sakta. Meherbani karke command text me likh kar bhej dein — misal: "aaj ki report do".'
                  : 'Assalam o Alaikum! Aap ki voice note mil gayi hai, lekin main abhi voice sun nahi sakta. Meherbani karke apna message text me likh kar bhej dein, main foran jawab dunga.')
              : (staff
                  ? 'Ye attachment main process nahi kar sakta — command text me likh kar bhej dein.'
                  : 'Assalam o Alaikum! Meherbani karke apna message text me likh kar bhej dein, main foran jawab dunga.');
            await wa.sendWhatsApp(from, note);
            continue;
          }
          const text = msg.text.body;
          if (staff) {
            const out = await brain.runCommand({ staffId: 'wa:' + digits(from), channel: 'whatsapp', text });
            await wa.sendWhatsApp(from, out.reply);
          } else {
            const out = await handleSalesMessage('wa-sales-' + digits(from), text, from);
            for (const r of out.replies) await wa.sendWhatsApp(from, r);
          }
        }
      }
    }
  } catch (e) { console.error('webhook error', e); }
});

/* ---------------- static ---------------- */
app.use('/login.html', express.static(path.join(__dirname, 'public', 'login.html')));
app.use(express.static(path.join(__dirname, 'public'), { index: false }));
app.get('/', auth, (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ error: 'Not found' });
  const sid = parseCookies(req).ac_sid;
  if (sid && sessions.has(sid)) return res.sendFile(path.join(__dirname, 'public', 'index.html'));
  return res.redirect('/login.html');
});

app.listen(PORT, () => {
  store.load();
  kn.loadKnowledge();
  scheduler.startScheduler();
  console.log(`Agent Core v2 running on port ${PORT} — brain mode: ${brain.brainMode()}`);
  console.log(`Login: ${ADMIN_USER} / ${ADMIN_PASS === 'change-me' ? 'change-me (DEFAULT — set ADMIN_PASS env!)' : '(from env)'}`);
});
